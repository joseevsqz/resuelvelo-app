# Resuélvelo

Aplicación web personal para organizar pendientes, compras, pagos y tareas.

## Cómo abrirla
- Descomprime el ZIP.
- Abre `index.html` con tu navegador.

La app funciona en el navegador y guarda los pendientes en el almacenamiento local de ese navegador.

## Para probarla
1. Crea un pendiente.
2. Asigna categoría, prioridad y fecha opcional.
3. Edita, completa, busca y elimina tareas.
4. Recarga la página y comprueba que los datos siguen allí.

## Limitaciones de esta primera versión
- Los datos no se sincronizan entre dispositivos.
- No hay cuentas de usuario ni recordatorios push.
- La instalación PWA y el modo sin conexión requieren servirla desde un sitio web mediante HTTPS o localhost; abrir el HTML directamente permite usar las funciones principales, pero no activar el service worker.
- No se conecta a ningún servidor ni envía datos.
